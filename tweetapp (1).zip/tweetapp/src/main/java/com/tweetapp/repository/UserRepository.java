package com.tweetapp.repository;

import java.util.List;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;

import com.tweetapp.model.User;

@EnableScan
public interface UserRepository extends CrudRepository<User, String>{

	User findByUsername(String username);

	List<User> findByUsernameLike(String username);

}