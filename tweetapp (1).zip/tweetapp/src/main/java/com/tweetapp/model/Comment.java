package com.tweetapp.model;

import java.util.Date;

import org.springframework.data.annotation.Id;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.tweetapp.constants.ServiceConstants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@DynamoDBTable(tableName = ServiceConstants.COMMENT_COLLECTION_TABLE)
@Data
@AllArgsConstructor
@NoArgsConstructor
@DynamoDBDocument
public class Comment {
	
	String commentId;
	String postId;
	String author;
	String commentMessage;
	Date dateOfComment;
	
}