package com.tweetapp.model;


import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.tweetapp.constants.ServiceConstants;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@DynamoDBTable(tableName = ServiceConstants.USER_COLLECTION_TABLE)
public class User {
	@DynamoDBHashKey
	String username;
	@DynamoDBAttribute
	String email;
	//@ApiModelProperty(hidden = true)
	@DynamoDBAttribute
	String password;
	@DynamoDBAttribute
	String firstName;
	@DynamoDBAttribute
	String lastName;
	@DynamoDBAttribute
	String contactNumber;
	@DynamoDBAttribute
	String gender;		
}